import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'case-search',
  templateUrl: './case-search.component.html',
  styleUrls: ['./case-search.component.css']
})
export class CaseSearchComponent{
  public caseList: any[]  =[
        {
          name: 'Ui -problem',
          description: 'UI design is modified.'
        },
        {
          name: 'Angular Incident Testing',
          description: 'Incident is reported for testing.'
        },
        {
          name: 'Case Type 2',
          description: 'Testing data to test functionality.'
        }
      ];
    public searchObj:any={"caseName":"","caseDescription":""};
    public caseList2=this.caseList;



  @Input('inputobj')
  set inputobj(inputobj: string) {
    console.log('got inputobj: ', inputobj);
    this.displayResult(inputobj);
    //this.caseList = JSON.parse(inputobj);
  }

  displayResult(search:string){
    console.log("In Display call");

    this.searchObj=JSON.parse(search);
    if(this.searchObj==null)
      this.caseList=this.caseList;
    else
    for(var i=0;i<this.caseList.length;i++)
    {
      if(this.caseList[i].name.indexOf(this.searchObj.caseName) > -1 || this.caseList[i].description.indexOf(this.searchObj.caseDescription)>-1){
        this.caseList.push(this.caseList[i]);
      }
    }
  }



  constructor() {
    // tslint:disable-next-line:no-console
  //  console.debug(this.inputobj);
  this.caseList2=this.caseList;
  }


}
