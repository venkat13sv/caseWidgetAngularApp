import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent {
  public booksList: any[]  =[
        {
          name: 'Ui -problem',
          description: 'UI design is modified.'
        },
        {
          name: 'Angular Incident Testing',
          description: 'Incident is reported for testing.'
        },
        {
          name: 'Case Type 2',
          description: 'Testing data to test functionality.'
        }
      ];
    public searchObj:any={"caseName":"","caseDescription":""};
    public booksList2=this.booksList;



  @Input('books')
  set books(books: string) {
    console.log('got books: ', books);
    this.displayResult(books);
    //this.booksList = JSON.parse(books);
  }

  displayResult(search:string){
    console.log("In Display call");

    this.searchObj=JSON.parse(search);
    if(this.searchObj==null)
      this.booksList2=this.booksList;
    else
    for(var i=0;i<this.booksList.length;i++)
    {
      if(this.booksList[i].name.indexOf(this.searchObj.caseName) > -1 || this.booksList[i].description.indexOf(this.searchObj.caseDescription)){
        this.booksList2.append(this.booksList[i]);
      }
    }
  }

//  @Output('bookSelected') bookSelected = new EventEmitter<any>();

  constructor() {
    // tslint:disable-next-line:no-console
    console.debug(this.books);
  }

/*  selected(book: any) {
    this.bookSelected.emit(JSON.stringify(book));
  }*/
}
