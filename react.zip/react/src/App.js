import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props){
    super(props);
    this.searchCases=this.searchCases.bind(this);
    this.state = {

      inputobj:{
        caseName:"",
        caseDescription:""
      }
    };
  }





  setCaseName=(e)=>{
    this.setState({inputobj:
      {
        caseName: e.target.value
      }});
      console.log(e.target.value);

  }
  searchCases(){

  }






  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Case Information Search.</h1>
          <div className="title"></div>
          <div className="search ">
             <input type="text" name="caseId"  className="searchTerm" placeholder="Case Id" defaultValue="" onChange={e => this.setCaseId(e)} />
             <input type="text" name="caseName" className="searchTerm" placeholder="Case Name" defaultValue="" onChange={e => this.setCaseName(e)}/>
             <input type="text" name="caseType" className="searchTerm" placeholder="Case Type" defaultValue="" onChange={e => this.setCaseType(e)} />
             <button type="submit" className="searchButton" onClick={this.searchCases}>
              <i className="fa fa-search"></i>
              </button>
          </div>
        </header>

        <div className="case-list">
          <case-search ref={elem => this.nv = elem} inputobj={JSON.stringify(this.state.inputobj)}></case-search>
        </div>
    
      </div>
    );
  }
}

export default App;
